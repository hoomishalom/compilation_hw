package ast;

public abstract class AstVar extends AstNode
{
}
