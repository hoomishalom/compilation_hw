package ast;

public abstract class AstDecl extends AstStmt
{
}
